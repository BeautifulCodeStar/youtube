'use strict';
var async = require('async');
var request = require('request');

var key = "AIzaSyAUlAMtJl96h0aUODNvlzhTfVLY12X7IzE";

var nextPageToken = '';
//var channelId = 'UCCcVQKtF8zHVQoTJt8NNMJA';
var channelIds = ["UCCcVQKtF8zHVQoTJt8NNMJA","UC2J7masgTZkHUiVowVJi6eg","UC2AmGRHTJoUhChm_rmJlXfQ","UChDaEjWqLQ_FMWioF4pHqhw","UCL_SZi70jqSrttwm_LL0cuA","UCQBu4FJMzuc6ME8dbrWJV6g","UChAYWoErHbS0CNvEXO3eJKw","UC_jM74fkz2JBaNET0mVwg1Q","UCzIsQCPkuNz2KZ-bhzeEiRg","UCk1UvIAkYJBrD6XXDMZ-HSg","UCE7nXtv4j6OtZ9GV3lmeroQ","UCqp6OhEmlbH1WpPObE9DFbg"];
//var playlistId = 'PL4QjLDoG7TbOhXxdD1LOs4o9X9xhwylN7';
//var urlPlaylist = 'https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=' + channelId + '&maxResults=50&pageToken=' + pageToken + '&key=' + key;
//var urlVideo = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&playlistId=' + playlistId + '&key=' + key;
var videoJson;
var count = 1;
var gotAllPlaylists = false;
var ArrAllVideos = [];
var ArrAllPlaylists = [];

function videoIdRequest(playlistId, nextPageToken) {
	var urlVideo = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&maxResults=50&pageToken='+nextPageToken+'&playlistId=' + playlistId + '&key=' + key;
	return new Promise(function(resolve) {
		request.get({
			url: urlVideo,
			json: true,
			headers: {'User-Agent': 'request'}
		}, (err, res, json) => {
			if (err) {
				console.log("error");
			} else if ( res.statusCode !== 200) {
				console.log(res.statusCode);
			} else {
				resolve(json);
			}
		})
	})
	.then(function(json) {
		var nextPageToken = json.nextPageToken;
		for (var i = 0; i<json.items.length; i++) {
			var videoId = json.items[i].snippet.resourceId.videoId;
			var title = json.items[i].snippet.title;
			ArrAllVideos.push({'videoId':videoId, 'title':title});
		}
		return nextPageToken
            ? videoIdRequest(playlistId, nextPageToken)
            : ArrAllVideos;
	})
}

function playlistsRequest(channelId, nextPageToken) {
    var url = 'https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId='+channelId+'&maxResults=50&pageToken=' + nextPageToken + '&key=' + key;

    return new Promise(function (resolve) {
       request.get({
	    	url: url,
	    	json: true,
	    	headers: {'User-Agent': 'request'}
	  	}, (err, res, json) => {
	    	if (err) {
	      		console.log('Error:', err);
	    	} else if (res.statusCode !== 200) {
	      		console.log('Status:', res.statusCode, json.error.erros);	
	      		reject();
	    	} else {
	      		resolve(json);
	    	}
	  	});
    })
    .then(async function (json) {
    	// var channelId = 'UCCcVQKtF8zHVQoTJt8NNMJA';
    	var nextPageToken = json.nextPageToken;
    	console.log('playlistId nextPageToken:', nextPageToken);
		for (var i = 0; i<json.items.length; i++) {
			var channelId = json.items[i].snippet.channelId;
			var channelTitle = json.items[i].snippet.channelTitle;
			var playlistId = json.items[i].id;
			var playlistTitle = json.items[i].snippet.title;
			
			ArrAllPlaylists.push({
				'channelId': channelId,
				'channelTitle': channelTitle,
				'playlistId': playlistId,
				'playlistTitle': playlistTitle,
				'videoDetails':[],
			});
		}
		
        return nextPageToken
            ? playlistsRequest(channelId, json.nextPageToken)
            : true;
    });
}

let task = async function asyncCall() {
	
	for (var i=0; i< channelIds.length;i++) {
		var channelId = channelIds[i];
		var nextPageToken = '';
		let firstResult = await playlistsRequest(channelId, nextPageToken);
	}

	for (var i=0; i < ArrAllPlaylists.length; i++) {
		var videoDetails = await videoIdRequest(ArrAllPlaylists[i].playlistId, '');
		ArrAllPlaylists[i].videoDetails = videoDetails;
	}

	console.log(ArrAllPlaylists);
}

task();